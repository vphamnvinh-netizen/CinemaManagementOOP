using System;
using System.Collections.Generic;

public interface IBanDuoc
{
    double LayGia();
    string LayMoTa();
}


public interface IChinhSachThanhVien
{
    int TinhDiemTichLuy(double soTien);
    double TinhGiamGia(double soTien);
}


public abstract class SanPhamRap : IBanDuoc
{
    private string ten = "";
    private double giaCoBan;

    public abstract string LoaiSanPham();
    public string Ten
    {
        get { return ten; }
        set { ten = value; }
    }

    public double GiaCoBan
    {
        get { return giaCoBan; }
        set
        {
            if (value > 0)
                giaCoBan = value;
        }
    }

    public abstract double LayGia();
    public abstract string LayMoTa();
}


public class Phim : SanPhamRap
{
    private int thoiLuongPhut;
    private string theLoai;
    private string doTuoiQuyDinh;

    public int ThoiLuongPhut
    {
        get { return thoiLuongPhut; }
        set
        {
            if (value > 0)
                thoiLuongPhut = value;
        }
    }

    public string TheLoai
    {
        get { return theLoai; }
        set { theLoai = value; }
    }

    public string DoTuoiQuyDinh
    {
        get { return doTuoiQuyDinh; }
        set { doTuoiQuyDinh = value; }
    }
    public override string LoaiSanPham()
    {
        return "Phim";
    }
    public Phim(string ten, double giaCoBan, int thoiLuongPhut, string theLoai, string doTuoiQuyDinh)
    {
        this.Ten = ten;
        this.GiaCoBan = giaCoBan;
        ThoiLuongPhut = thoiLuongPhut;
        this.theLoai = theLoai;
        this.doTuoiQuyDinh = doTuoiQuyDinh;
    }
    public static List<Phim> DSPhim = new List<Phim>
    {
       new Phim("Avatar 3",120000 , 180 , "Vien Tuong" , "K16"),
       new Phim("Trai Buon Nguoi",125000 , 135 , "Hanh Dong" , "K16"),
       new Phim("Ut Lan 2",110000 , 120 , "Kinh Di" , "K18"),
       new Phim("Doraemon",90000 , 120 , "Khoa hoc vien tuong , Hai" , "P"),
       new Phim("Conan",90000 , 120 , "Vien Tuong , Hai, Trinh Tham" , "T13")
    };
    public override double LayGia()
    {
        return GiaCoBan;
    }
    public override string LayMoTa()
    {
        return string.Format("Phim: {0} ({1}) - {2} phút - {3} VND", Ten, TheLoai, ThoiLuongPhut, LayGia());
    }
}

public class ComboBapNuoc : SanPhamRap
{
    private double giamGia;

    public double GiamGia
    {
        get { return giamGia; }
        set { if (value >= 0 && value <= 1) giamGia = value; }
    }

    public ComboBapNuoc(string ten, double giaCoBan, double giamGia)
    {
        this.Ten = ten;
        this.GiaCoBan = giaCoBan;
        GiamGia = giamGia;
    }
    public static List<ComboBapNuoc> Menu = new List<ComboBapNuoc>
    {
        new ComboBapNuoc("Bap Caramel",50000,0),
        new ComboBapNuoc("Bap Bo",40000,0),
        new ComboBapNuoc("Bap Socola",52000,0),
        new ComboBapNuoc("MyCombo", 95000, 0.1),
        new ComboBapNuoc("Premium My Combo", 115000, 0.15),
        new ComboBapNuoc("Family Combo", 220000, 0.2)
    };
    public override double LayGia()
    {
        return GiaCoBan * (1 - giamGia);
    }

    public override string LoaiSanPham()
    {
        return "Combo";
    }
    public override string LayMoTa()
    {
        return string.Format("Combo: {0} - {1} VND", Ten, LayGia());
    }

    public static void HienThiMenu()
    {
        Console.WriteLine("===== MENU BAP NUOC =====");
        for (int i = 0; i < Menu.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {Menu[i].Ten,-20} {Menu[i].LayGia(),10} VND");
        }
        Console.WriteLine("0. Quay lai");
    }

    public static ComboBapNuoc ChonCombo()
    {
        HienThiMenu();
         while (true)
        {
            Console.Write("Chon combo (nhap so): ");
            string input = Console.ReadLine() ?? "";
            if (int.TryParse(input, out int chon) && chon >= 0 && chon <= Menu.Count)
            {
                if (chon == 0)
                    return null;
                return Menu[chon - 1];
            }
            Console.WriteLine("Lua chon khong hop le. Vui long nhap lai.");
    }
    }
}


public class Ghe
{
    private string maGhe;
    private string loaiGhe;
    private bool daDat;

    public string MaGhe
    {
        get { return maGhe; }
    }

    public string LoaiGhe
    {
        get { return loaiGhe; }
    }

    public bool DaDat
    {
        get { return daDat; }
        private set { daDat = value; }
    }

    public Ghe(string maGhe, string loaiGhe)
    {
        this.maGhe = maGhe;
        this.loaiGhe = loaiGhe;
        this.daDat = false;
    }

    private static double giaNhap = 80000;
    public static double GiaNhap
    {
        get { return giaNhap; }
        set { giaNhap = value; }
    }
    public static void NhapGiaTuMay()
    {
        while (true)
        {
            Console.Write("Nhập giá ghế (VND): ");
            string input = Console.ReadLine() ?? "";
            if (double.TryParse(input, out double gia) && gia > 0)
            {
                GiaNhap = gia;
                break;
            }
            else
            {
                Console.WriteLine("Giá không hợp lệ. Vui lòng nhập lại.");
            }
        }
    }

    public static Ghe ChonGhe(PhongChieu phong)
    {
        if (phong == null)
        {
            Console.WriteLine("Khong co phong chieu.");
            return null;
        }

        if (phong.DemGheTrong() == 0)
        {
            Console.WriteLine("Phong da het ghe trong.");
            return null;
        }

        phong.HienThiSoDoGhe();

        while (true)
        {
            Console.Write("Nhap ma ghe (vi du A1), nhap 0 de huy: ");
            string ma = (Console.ReadLine() ?? "").Trim().ToUpper();

            if (ma == "0")
                return null;

            if (ma == "")
            {
                Console.WriteLine("Ma ghe khong duoc de trong. Nhap lai.");
                continue;
            }

            Ghe ghe = phong.LayGhe(ma);

            if (ghe == null)
            {
                Console.WriteLine("Khong tim thay ghe " + ma + " trong phong nay. Nhap lai.");
                continue;
            }

            if (ghe.DaDat)
            {
                Console.WriteLine("Ghe " + ma + " da co nguoi dat. Vui long chon ghe khac.");
                continue;
            }

            Console.WriteLine($"Da chon ghe {ghe.MaGhe} ({ghe.LoaiGhe}) - Gia ghe: {ghe.LayGiaGhe()} VND");
            return ghe;
        }
    }

    public double LayGiaGhe()
    {
        if (loaiGhe == "VIP")
        {
            return GiaNhap + (GiaNhap * 0.3);
        }
        else if (loaiGhe == "Doi")
        {
            return GiaNhap + (GiaNhap * 2);
        }
        else
        {
            return GiaNhap;
        }
    }

    public bool DatGhe()
    {
        if (daDat)
        {
            return false;
        }
        else
        {
            daDat = true;
            return true;
        }
    }

    public void HuyDat()
    {
        daDat = false;
    }
}

public class PhongChieu
{
    private string maPhong;
    private string tenPhong;
    private int soHang;
    private int soCot;
    private Ghe[,] soDoGhe;

    public string MaPhong
    {
        get { return maPhong; }
    }

    public string TenPhong
    {
        get { return tenPhong; }
    }

    public int SoHang
    {
        get { return soHang; }
    }

    public int SoCot
    {
        get { return soCot; }
    }

    public PhongChieu(string maPhong, string tenPhong, int soHang, int soCot)
    {
        this.maPhong = maPhong;
        this.tenPhong = tenPhong;
        this.soHang = soHang;
        this.soCot = soCot;
        this.soDoGhe = new Ghe[soHang, soCot];
        KhoiTaoGhe();
    }

    private void KhoiTaoGhe()
    {
        for (int i = 0; i < soHang; i++)
        {
            char tenHang = (char)('A' + i);
            string loai = "Thuong";
            if (i == soHang - 1)
            {
                loai = "Doi";
            }
            else if (i >= soHang / 2)
            {
                loai = "VIP";
            }
            for (int j = 0; j < soCot; j++)
            {
                string maGhe = tenHang.ToString() + (j + 1);
                soDoGhe[i, j] = new Ghe(maGhe, loai);
            }
        }
    }

    public Ghe LayGhe(string maGhe)
    {
        for (int i = 0; i < soHang; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                if (soDoGhe[i, j].MaGhe == maGhe)
                    return soDoGhe[i, j];
            }
        }
        return null;
    }

    public int DemGheTrong()
    {
        int dem = 0;
        for (int i = 0; i < soHang; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                if (!soDoGhe[i, j].DaDat)
                    dem++;
            }
        }
        return dem;
    }

    public void HienThiSoDoGhe()
    {
        Console.WriteLine("Sơ đồ ghế trong phòng " + tenPhong);
        for (int i = 0; i < soHang; i++)
        {
            Console.Write((char)('A' + i) + ":");
            for (int j = 0; j < soCot; j++)
            {
                Ghe ghe = soDoGhe[i, j];
                if (ghe.DaDat)
                {
                    Console.Write("[X] ");
                }
                else if (ghe.LoaiGhe == "VIP")
                {
                    Console.Write("[V] ");
                }
                else if (ghe.LoaiGhe == "Doi")
                {
                    Console.Write("[D] ");
                }
                else
                {
                    Console.Write("[ ] ");
                }
            }
            Console.WriteLine();
        }
        Console.WriteLine("[ ] Thuong  [V] VIP  [D] Doi  [X] Da dat");
    }
}

public class SuatChieu
{
    private string maSuat;
    private Phim phim;
    private PhongChieu phongChieu;
    private DateTime gioBatDau;
    private double giaCoBan;

    public string MaSuat
    {
        get { return maSuat; }
    }

    public Phim Phim
    {
        get { return phim; }
    }

    public PhongChieu PhongChieu
    {
        get { return phongChieu; }
    }

    public DateTime GioBatDau
    {
        get { return gioBatDau; }
    }

    public double GiaCoBan
    {
        get { return giaCoBan; }
    }

    public SuatChieu(string maSuat, Phim phim, PhongChieu phongChieu,
                     DateTime gioBatDau, double giaCoBan)
    {
        this.maSuat = maSuat;
        this.phim = phim;
        this.phongChieu = phongChieu;
        this.gioBatDau = gioBatDau;
        this.giaCoBan = giaCoBan;
    }

    public void HienThiThongTin()
    {
        Console.WriteLine("Suat chieu: " + maSuat);
        Console.WriteLine("Phim: {0} ({1} | {2})",phim.Ten,phim.TheLoai,phim.DoTuoiQuyDinh);
        Console.WriteLine("Phong: " + phongChieu.TenPhong);
        Console.WriteLine("Gio chieu: " + gioBatDau);
        Console.WriteLine("Ghe trong: " + phongChieu.DemGheTrong());
    }

    public static SuatChieu ChonSuatChieu(List<SuatChieu> lichChieu)
    {
        if (lichChieu == null || lichChieu.Count == 0)
        {
            Console.WriteLine("Hien chua co suat chieu nao.");
            return null;
        }

        Console.WriteLine("===== LICH CHIEU =====");
        for (int i = 0; i < lichChieu.Count; i++)
        {
            SuatChieu s = lichChieu[i];
            Console.WriteLine($"{i + 1}. [{s.MaSuat}] {s.Phim.Ten} ({s.Phim.TheLoai} | {s.Phim.DoTuoiQuyDinh}) | Phong: {s.PhongChieu.TenPhong} | " +
                              $"{s.GioBatDau.ToString("dd/MM/yyyy HH:mm")} | Ghe trong: {s.PhongChieu.DemGheTrong()} | " +
                              $"Gia: {s.GiaCoBan} VND");
        }
        Console.WriteLine("0. Quay lai");

        while (true)
        {
            Console.Write("Chon suat chieu (nhap so): ");
            string input = Console.ReadLine() ?? "";
            if (int.TryParse(input, out int chon) && chon >= 0 && chon <= lichChieu.Count)
            {
                if (chon == 0)
                    return null;
                return lichChieu[chon - 1];
            }
            Console.WriteLine("Lua chon khong hop le. Vui long nhap lai.");
        }
    }
}

public class KhachHang : IChinhSachThanhVien
{
    private string maKhachHang;
    private string hoTen;
    private string soDienThoai;
    private int diemTichLuy;
    private string hangThanhVien;

    public string MaKhachHang
    {
        get { return maKhachHang; }
    }

    public string HoTen
    {
        get { return hoTen; }
    }

    public string SoDienThoai
    {
        get { return soDienThoai; }
    }

    public int DiemTichLuy
    {
        get { return diemTichLuy; }
    }

    public string HangThanhVien
    {
        get { return hangThanhVien; }
    }
    public KhachHang()
    {
        this.diemTichLuy = 0;
        this.hangThanhVien = "Standard";
    }
    public KhachHang(string maKhachHang, string hoTen, string soDienThoai)
    {
        this.maKhachHang = maKhachHang;
        this.hoTen = hoTen;
        this.soDienThoai = soDienThoai;
        this.diemTichLuy = 0;
        this.hangThanhVien = "Standard";
    }

    public int TinhDiemTichLuy(double soTien)
    {
        if (soTien <= 0)
        {
            return 0;
        }
        return (int)(soTien / 10000);
    }

    public double TinhGiamGia(double soTien)
    {
        if (hangThanhVien == "Gold")
        {
            return soTien * 0.2;
        }
        else if (hangThanhVien == "Silver")
        {
            return soTien * 0.1;
        }
        else
        {
            return 0;
        }
    }

    public void CongDiem(double soTien)
    {
        diemTichLuy += TinhDiemTichLuy(soTien);
        CapNhatHang();
    }

    public void CapNhatHang()
    {
        if (diemTichLuy >= 1000)
        {
            hangThanhVien = "Gold";
        }
        else if (diemTichLuy >= 500)
        {
            hangThanhVien = "Silver";
        }
        else
        {
            hangThanhVien = "Standard";
        }
    }
    public void Nhap()
    {
        Console.Write("Ma Khach Hang : "); maKhachHang = Console.ReadLine() ?? "";
        Console.Write("Ho Ten Khach : "); hoTen = Console.ReadLine() ?? "";
        Console.Write("SDT : "); soDienThoai = Console.ReadLine() ?? "";
    }
    public void HienThiThongTin()
    {
        CapNhatHang();
        Console.WriteLine("Khach hang: " + hoTen + " (" + maKhachHang + ")");
        Console.WriteLine("So dien thoai: " + soDienThoai);
        Console.WriteLine("Diem tich luy: " + diemTichLuy);
        Console.WriteLine("Hang thanh vien: " + hangThanhVien);
    }
}


public class Ve : IBanDuoc
{
    private string maVe;
    private SuatChieu suatChieu;
    private Ghe ghe;
    private KhachHang khachHang;
    private double giaVe;
    private DateTime ngayDat;
    private bool daHuy;

    private static int demVe = 0;  

    public string MaVe
    {
        get { return maVe; }
    }

    public SuatChieu SuatChieu
    {
        get { return suatChieu; }
    }

    public Ghe Ghe
    {
        get { return ghe; }
    }

    public KhachHang KhachHang
    {
        get { return khachHang; }
    }

    public double GiaVe
    {
        get { return giaVe; }
    }

    public bool DaHuy
    {
        get { return daHuy; }
    }

    public Ve(string maVe, SuatChieu suatChieu, Ghe ghe, KhachHang khachHang)
    {
        this.maVe = maVe;
        this.suatChieu = suatChieu;
        this.ghe = ghe;
        this.khachHang = khachHang;
        this.ngayDat = DateTime.Now;
        this.daHuy = false;
        TinhGiaVe();
    }

    public static string SinhMaVe()
    {
        demVe++;
        return "V" + demVe.ToString("000");
    }

    public static Ve DatVe(List<SuatChieu> lichChieu, KhachHang khachHang)
    {
        if (khachHang == null)
        {
            Console.WriteLine("Chua co thong tin khach hang.");
            return null;
        }

        SuatChieu suat = SuatChieu.ChonSuatChieu(lichChieu);
        if (suat == null)
        {
            Console.WriteLine("Da huy thao tac dat ve.");
            return null;
        }

        Ghe gheChon = Ghe.ChonGhe(suat.PhongChieu);
        if (gheChon == null)
        {
            Console.WriteLine("Da huy thao tac dat ve.");
            return null;
        }

        if (!gheChon.DatGhe())
        {
            Console.WriteLine("Ghe vua bi dat mat. Vui long thu lai.");
            return null;
        }

        Ve ve = new Ve(SinhMaVe(), suat, gheChon, khachHang);
        NhatKyHeThong.GhiLog($"Dat ve {ve.MaVe} - ghe {gheChon.MaGhe} - suat {suat.MaSuat}");
        Console.WriteLine("--- Dat ve thanh cong ---");
        ve.HienThiThongTin();
        return ve;
    }

    private void TinhGiaVe()
    {
        double giaPhim = suatChieu.GiaCoBan;
        double giaGhe = ghe.LayGiaGhe();
        double giamGia = khachHang.TinhGiamGia(giaPhim + giaGhe);
        giaVe = giaPhim + giaGhe - giamGia;
    }
    public static double operator +(Ve a, Ve b)
    {
        return a.giaVe + b.giaVe;
    }
    public static double operator +(double tong, Ve v)
    {
        return tong + v.giaVe;
    }
    public double LayGia()
    {
        return giaVe;
    }
    public string LayMoTa()
    {
        return "Ve: " + maVe + " - Suat chieu: " + suatChieu.MaSuat + " - Ghe: " + ghe.MaGhe + " - Gia: " + giaVe + " VND";
    }

    public bool HuyVe()
    {
        if (daHuy)
        {
            return false;
        }
        else
        {
            daHuy = true;
            ghe.HuyDat();
            return true;
        }
    }
    public string NoidungIn()
    {
        string noiDung = "Ma ve: " + maVe + "\n";
        noiDung += "Phim: " + suatChieu.Phim.Ten + "\n";
        noiDung += "Ghe: " + ghe.MaGhe + "\n";
        noiDung += "Khach hang: " + khachHang.HoTen + "\n";
        noiDung += "Gia ve: " + giaVe + " VND";
        return noiDung;
    }

    public void HienThiThongTin()
    {
        Console.WriteLine(NoidungIn());
    }
}


public class HoaDon<T> where T : IBanDuoc
{
    private string maHoaDon;
    private DateTime ngayLap;
    private KhachHang khachHang;
    private List<T> danhSach;
    private double tongTien;

    public string MaHoaDon
    {
        get { return maHoaDon; }
    }

    public KhachHang KhachHang
    {
        get { return khachHang; }
    }

    public double TongTien
    {
        get { return tongTien; }
    }

    public int SoLuongMon
    {
        get { return danhSach.Count; }
    }

    public HoaDon(string maHoaDon, KhachHang khachHang)
    {
        this.maHoaDon = maHoaDon;
        this.khachHang = khachHang;
        this.ngayLap = DateTime.Now;
        this.danhSach = new List<T>();
        this.tongTien = 0;
    }

    public void Them(T ve)
    {
        if (ve == null)
        {
            Console.WriteLine("Mon khong hop le.");
            return;
        }
        danhSach.Add(ve);
        TinhTongTien();
    }
    private void TinhTongTien()
    {
        tongTien = 0;
        foreach (T mon in danhSach)
        {
            tongTien = tongTien + mon.LayGia();
        }
    }

    public void NhapMaHoaDon()
    {
        while (true)
        {
            Console.Write("Nhap ma hoa don: ");
            string ma = (Console.ReadLine() ?? "").Trim();
            if (ma != "")
            {
                maHoaDon = ma;
                break;
            }
            Console.WriteLine("Ma hoa don khong duoc de trong. Nhap lai.");
        }
    }

    public void Nhap(List<SuatChieu> lichChieu)
    {
        NhapMaHoaDon();

        bool dangMua = true;
        while (dangMua)
        {
            Console.WriteLine();
            Console.WriteLine("===== MENU MUA HANG =====");
            Console.WriteLine("1. Dat ve xem phim");
            Console.WriteLine("2. Mua combo bap nuoc");
            Console.WriteLine("3. Xem hoa don tam tinh");
            Console.WriteLine("0. Ket thuc va thanh toan");
            Console.Write("Lua chon: ");
            string chon = (Console.ReadLine() ?? "").Trim();

            switch (chon)
            {
                case "1":
                    Ve ve = Ve.DatVe(lichChieu, khachHang);
                    if (ve is T monVe)
                        Them(monVe);
                    break;

                case "2":
                    ComboBapNuoc combo = ComboBapNuoc.ChonCombo();
                    if (combo is T monCombo)
                    {
                        Them(monCombo);
                        Console.WriteLine($"Da them: {combo.LayMoTa()}");
                    }
                    break;

                case "3":
                    HienThiHoaDon();
                    break;

                case "0":
                    if (danhSach.Count == 0)
                    {
                        Console.WriteLine("Hoa don dang trong. Ban co chac muon thoat? (c/k): ");
                        string xacNhan = (Console.ReadLine() ?? "").Trim().ToLower();
                        if (xacNhan != "c")
                            break;
                    }
                    dangMua = false;
                    break;

                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long nhap lai.");
                    break;
            }
        }

        NhatKyHeThong.GhiLog($"Lap hoa don {maHoaDon} - {danhSach.Count} mon - {tongTien} VND");
    }

    public string HoaDonIn()
    {
        string noiDung = "===== HOA DON =====\n";
        noiDung += $"Ma hoa don: {maHoaDon}\n";
        noiDung += $"Ngay lap: {ngayLap.ToString("dd/MM/yyyy HH:mm")}\n";
        noiDung += $"Khach hang: {khachHang.HoTen}\n";
        noiDung += "------- DANH SACH -------\n";
        foreach (T mon in danhSach)
        {
            noiDung += mon.LayMoTa() + "\n";
        }
        noiDung += $"Tong tien: {tongTien} VND";
        return noiDung;
    }

    public void HienThiHoaDon()
    {
        Console.WriteLine(HoaDonIn());
    }
}
public class CumRap
{
    private string maCumRap;
    private string tenCumRap;
    private string diaChi;
    private List<PhongChieu> danhSachPhong;
    private List<SuatChieu> lichChieu;
    private double doanhThu;

    public string MaCumRap
    {
        get { return maCumRap; }
    }

    public string TenCumRap
    {
        get { return tenCumRap; }
    }

    public double DoanhThu
    {
        get { return doanhThu; }
    }

    public CumRap(string maCumRap, string tenCumRap, string diaChi)
    {
        this.maCumRap = maCumRap;
        this.tenCumRap = tenCumRap;
        this.diaChi = diaChi;
        this.danhSachPhong = new List<PhongChieu>();
        this.lichChieu = new List<SuatChieu>();
        this.doanhThu = 0;
    }

    public void ThemPhongChieu(PhongChieu phong)
    {
        if (phong != null)
        {
            danhSachPhong.Add(phong);
        }
    }

    public void ThemSuatChieu(SuatChieu suat)
    {
        if (suat != null)
        {
            lichChieu.Add(suat);
        }
    }

    public void CapNhatDoanhThu(double tien)
    {
        if (tien > 0)
        {
            doanhThu += tien;
        }
    }

    public List<PhongChieu> LayDanhSachPhong()
    {
        return danhSachPhong;
    }

    public List<SuatChieu> LayLichChieu()
    {
        return lichChieu;
    }

    public void HienThiThongTin()
    {
        Console.WriteLine($"Cum rap: {tenCumRap} ({maCumRap})");
        Console.WriteLine($"Dia chi: {diaChi}");
        Console.WriteLine($"So phong chieu: {danhSachPhong.Count}");
        Console.WriteLine($"So suat chieu: {lichChieu.Count}");
        Console.WriteLine($"Doanh thu: {doanhThu} VND");
    }
}


public static class NhatKyHeThong
{
    private static List<string> nhatKy = new List<string>();

    public static void GhiLog(string noiDung)
    {
        string log = $"{DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")} - {noiDung}";
        nhatKy.Add(log);
    }

    public static void HienThiNhatKy()
    {
        Console.WriteLine("===== NHAT KY HE THONG =====");
        if (nhatKy.Count == 0)
        {
            Console.WriteLine("Khong co ban ghi nao.");
            return;
        }
        foreach (string log in nhatKy)
        {
            Console.WriteLine(log);
        }
    }

    public static int SoLuongLog()
    {
        return nhatKy.Count;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        CumRap rap = new CumRap("CR01", "Rap Phim VinCom", "1 Vo Van Ngan, Thu Duc");

        PhongChieu p1 = new PhongChieu("P01", "Phong 1", 5, 8);
        PhongChieu p2 = new PhongChieu("P02", "Phong 2", 4, 6);
        rap.ThemPhongChieu(p1);
        rap.ThemPhongChieu(p2);

        DateTime homNay = DateTime.Today;
        rap.ThemSuatChieu(new SuatChieu("SC01", Phim.DSPhim[0], p1, homNay.AddHours(18), Phim.DSPhim[0].LayGia()));
        rap.ThemSuatChieu(new SuatChieu("SC02", Phim.DSPhim[1], p1, homNay.AddHours(21), Phim.DSPhim[1].LayGia()));
        rap.ThemSuatChieu(new SuatChieu("SC03", Phim.DSPhim[2], p2, homNay.AddHours(19), Phim.DSPhim[2].LayGia()));
        rap.ThemSuatChieu(new SuatChieu("SC04", Phim.DSPhim[3], p2, homNay.AddHours(12), Phim.DSPhim[3].LayGia()));
        rap.ThemSuatChieu(new SuatChieu("SC05", Phim.DSPhim[4], p2, homNay.AddHours(16), Phim.DSPhim[4].LayGia()));
        

        Ghe.NhapGiaTuMay();

        Console.WriteLine("===== THONG TIN KHACH HANG =====");
        KhachHang khach = new KhachHang();
        khach.Nhap();
        NhatKyHeThong.GhiLog("Nhap khach hang: " + khach.HoTen);

        HoaDon<IBanDuoc> hoaDon = new HoaDon<IBanDuoc>("", khach);
        hoaDon.Nhap(rap.LayLichChieu());

        if (hoaDon.SoLuongMon > 0)
        {
            Console.WriteLine();
            hoaDon.HienThiHoaDon();
            rap.CapNhatDoanhThu(hoaDon.TongTien);
            khach.CongDiem(hoaDon.TongTien);
        }

        Console.WriteLine();
        khach.HienThiThongTin();
        Console.WriteLine();
        rap.HienThiThongTin();
        Console.WriteLine();
        NhatKyHeThong.HienThiNhatKy();
    }
}
