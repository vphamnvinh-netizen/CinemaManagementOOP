from abc import ABC, abstractmethod

class IBanDuoc(ABC):
    @abstractmethod
    def LayGia(self):
        pass

    @abstractmethod
    def LayMoTa(self):
        pass


class IChinhSachThanhVien(ABC):
    @abstractmethod
    def TinhDiemTichLuy(self, soTien):
        pass

    @abstractmethod
    def TinhGiamGia(self, soTien):
        pass

class SanPhamRap(IBanDuoc):
    def __init__(self, ten="", giaCoBan=0):
        self.__ten = ten
        self.__giaCoBan = 0
        self.setGiaCoBan(giaCoBan)

    def getTen(self):
        return self.__ten

    def setTen(self, ten):
        self.__ten = ten

    def getGiaCoBan(self):
        return self.__giaCoBan

    def setGiaCoBan(self, gia):
        if gia > 0:
            self.__giaCoBan = gia

    @abstractmethod
    def LoaiSanPham(self):
        pass


class Phim(SanPhamRap):
    def __init__(self, ten, giaCoBan, thoiLuongPhut, theLoai, doTuoiQuyDinh):
        super().__init__(ten, giaCoBan)
        self.__thoiLuongPhut = 0
        self.setThoiLuongPhut(thoiLuongPhut)
        self.__theLoai = theLoai
        self.__doTuoiQuyDinh = doTuoiQuyDinh

    def getThoiLuongPhut(self):
        return self.__thoiLuongPhut

    def setThoiLuongPhut(self, phut):
        if phut > 0:
            self.__thoiLuongPhut = phut

    def getTheLoai(self):
        return self.__theLoai

    def getDoTuoiQuyDinh(self):
        return self.__doTuoiQuyDinh

    def LoaiSanPham(self):
        return "Phim"

    def LayGia(self):
        return self.getGiaCoBan()

    def LayMoTa(self):
        return f"Phim: {self.getTen()} ({self.__theLoai}) - {self.__thoiLuongPhut} phut - {self.LayGia()} VND"


DSPhim = [
    Phim("Avatar 3", 120000, 180, "Vien Tuong", "K16"),
    Phim("Trai Buon Nguoi", 125000, 135, "Hanh Dong", "K16"),
    Phim("Ut Lan 2", 110000, 120, "Kinh Di", "K18"),
    Phim("Doraemon", 90000, 120, "Khoa hoc vien tuong, Hai", "P"),
    Phim("Conan", 90000, 120, "Vien Tuong, Hai, Trinh Tham", "T13"),
]


class ComboBapNuoc(SanPhamRap):
    def __init__(self, ten, giaCoBan, giamGia):
        super().__init__(ten, giaCoBan)
        self.__giamGia = 0
        self.setGiamGia(giamGia)

    def getGiamGia(self):
        return self.__giamGia

    def setGiamGia(self, giamGia):
        if 0 <= giamGia <= 1:
            self.__giamGia = giamGia

    def LoaiSanPham(self):
        return "Combo"

    def LayGia(self):
        return self.getGiaCoBan() * (1 - self.__giamGia)

    def LayMoTa(self):
        return f"Combo: {self.getTen()} - {self.LayGia()} VND"

    @staticmethod
    def HienThiMenu():
        print("===== MENU BAP NUOC =====")
        for i in range(len(Menu)):
            print(f"{i + 1}. {Menu[i].getTen()} - {Menu[i].LayGia()} VND")
        print("0. Quay lai")

    @staticmethod
    def ChonCombo():
        ComboBapNuoc.HienThiMenu()
        while True:
            chon = input("Chon combo (nhap so): ")
            if chon.isdigit() and 0 <= int(chon) <= len(Menu):
                if int(chon) == 0:
                    return None
                return Menu[int(chon) - 1]
            print("Lua chon khong hop le. Vui long nhap lai.")


Menu = [
    ComboBapNuoc("Bap Caramel", 50000, 0),
    ComboBapNuoc("Bap Bo", 40000, 0),
    ComboBapNuoc("Bap Socola", 52000, 0),
    ComboBapNuoc("MyCombo", 95000, 0.1),
    ComboBapNuoc("Premium My Combo", 115000, 0.15),
    ComboBapNuoc("Family Combo", 220000, 0.2),
]

class Ghe:
    giaNhap = 80000  

    def __init__(self, maGhe, loaiGhe):
        self.__maGhe = maGhe
        self.__loaiGhe = loaiGhe
        self.__daDat = False

    def getMaGhe(self):
        return self.__maGhe

    def getLoaiGhe(self):
        return self.__loaiGhe

    def getDaDat(self):
        return self.__daDat

    @staticmethod
    def NhapGiaTuMay():
        while True:
            gia = input("Nhap gia ghe (VND): ")
            if gia.isdigit() and int(gia) > 0:
                Ghe.giaNhap = int(gia)
                break
            print("Gia khong hop le. Vui long nhap lai.")

    @staticmethod
    def ChonGhe(phong):
        if phong is None:
            print("Khong co phong chieu.")
            return None
        if phong.DemGheTrong() == 0:
            print("Phong da het ghe trong.")
            return None

        phong.HienThiSoDoGhe()
        while True:
            ma = input("Nhap ma ghe (vi du A1), nhap 0 de huy: ").strip().upper()
            if ma == "0":
                return None
            if ma == "":
                print("Ma ghe khong duoc de trong. Nhap lai.")
                continue

            ghe = phong.LayGhe(ma)
            if ghe is None:
                print(f"Khong tim thay ghe {ma} trong phong nay. Nhap lai.")
                continue
            if ghe.getDaDat():
                print(f"Ghe {ma} da co nguoi dat. Vui long chon ghe khac.")
                continue

            print(f"Da chon ghe {ghe.getMaGhe()} ({ghe.getLoaiGhe()}) - Gia ghe: {ghe.LayGiaGhe()} VND")
            return ghe

    def LayGiaGhe(self):
        if self.__loaiGhe == "VIP":
            return Ghe.giaNhap + Ghe.giaNhap * 0.3
        elif self.__loaiGhe == "Doi":
            return Ghe.giaNhap + Ghe.giaNhap * 2
        else:
            return Ghe.giaNhap

    def DatGhe(self):
        if self.__daDat:
            return False
        self.__daDat = True
        return True

    def HuyDat(self):
        self.__daDat = False


class PhongChieu:
    CacHang = "ABCDEFGH"

    def __init__(self, maPhong, tenPhong, soHang, soCot):
        self.__maPhong = maPhong
        self.__tenPhong = tenPhong
        self.__soHang = soHang
        self.__soCot = soCot
        self.__soDoGhe = []  
        self.KhoiTaoGhe()

    def getMaPhong(self):
        return self.__maPhong

    def getTenPhong(self):
        return self.__tenPhong

    def KhoiTaoGhe(self):
        for i in range(self.__soHang):
            tenHang = PhongChieu.CacHang[i]
            loai = "Thuong"
            if i == self.__soHang - 1:
                loai = "Doi"
            elif i >= self.__soHang // 2:
                loai = "VIP"
            hang = []
            for j in range(self.__soCot):
                hang.append(Ghe(tenHang + str(j + 1), loai))
            self.__soDoGhe.append(hang)

    def LayGhe(self, maGhe):
        for hang in self.__soDoGhe:
            for ghe in hang:
                if ghe.getMaGhe() == maGhe:
                    return ghe
        return None

    def DemGheTrong(self):
        dem = 0
        for hang in self.__soDoGhe:
            for ghe in hang:
                if not ghe.getDaDat():
                    dem += 1
        return dem

    def HienThiSoDoGhe(self):
        print("So do ghe trong phong " + self.__tenPhong)
        for i in range(self.__soHang):
            print(PhongChieu.CacHang[i] + ":", end="")
            for ghe in self.__soDoGhe[i]:
                if ghe.getDaDat():
                    print("[X] ", end="")
                elif ghe.getLoaiGhe() == "VIP":
                    print("[V] ", end="")
                elif ghe.getLoaiGhe() == "Doi":
                    print("[D] ", end="")
                else:
                    print("[ ] ", end="")
            print()
        print("[ ] Thuong  [V] VIP  [D] Doi  [X] Da dat")


class SuatChieu:
    def __init__(self, maSuat, phim, phongChieu, gioBatDau, giaCoBan):
        self.__maSuat = maSuat
        self.__phim = phim
        self.__phongChieu = phongChieu
        self.__gioBatDau = gioBatDau
        self.__giaCoBan = giaCoBan

    def getMaSuat(self):
        return self.__maSuat

    def getPhim(self):
        return self.__phim

    def getPhongChieu(self):
        return self.__phongChieu

    def getGioBatDau(self):
        return self.__gioBatDau

    def getGiaCoBan(self):
        return self.__giaCoBan

    def Xuat(self):
        print("Suat chieu:", self.__maSuat)
        print("Phim:", self.__phim.getTen())
        print("Phong:", self.__phongChieu.getTenPhong())
        print("Gio chieu:", self.__gioBatDau)
        print("Ghe trong:", self.__phongChieu.DemGheTrong())

    @staticmethod
    def ChonSuatChieu(lichChieu):
        if not lichChieu:
            print("Hien chua co suat chieu nao.")
            return None

        print("===== LICH CHIEU =====")
        for i in range(len(lichChieu)):
            s = lichChieu[i]
            print(f"{i + 1}. [{s.getMaSuat()}] {s.getPhim().getTen()} | Phong: {s.getPhongChieu().getTenPhong()} | "
                  f"{s.getGioBatDau()} | Ghe trong: {s.getPhongChieu().DemGheTrong()} | "
                  f"Gia: {s.getGiaCoBan()} VND")
        print("0. Quay lai")

        while True:
            chon = input("Chon suat chieu (nhap so): ")
            if chon.isdigit() and 0 <= int(chon) <= len(lichChieu):
                if int(chon) == 0:
                    return None
                return lichChieu[int(chon) - 1]
            print("Lua chon khong hop le. Vui long nhap lai.")

class KhachHang(IChinhSachThanhVien):
    def __init__(self, maKhachHang="", hoTen="", soDienThoai=""):
        self.__maKhachHang = maKhachHang
        self.__hoTen = hoTen
        self.__soDienThoai = soDienThoai
        self.__diemTichLuy = 0
        self.__hangThanhVien = "Standard"

    def getHoTen(self):
        return self.__hoTen

    def getDiemTichLuy(self):
        return self.__diemTichLuy

    def getHangThanhVien(self):
        return self.__hangThanhVien

    def TinhDiemTichLuy(self, soTien):
        if soTien <= 0:
            return 0
        return int(soTien / 10000)

    def TinhGiamGia(self, soTien):
        if self.__hangThanhVien == "Gold":
            return soTien * 0.2
        elif self.__hangThanhVien == "Silver":
            return soTien * 0.1
        return 0

    def CongDiem(self, soTien):
        self.__diemTichLuy += self.TinhDiemTichLuy(soTien)
        self.CapNhatHang()

    def CapNhatHang(self):
        if self.__diemTichLuy >= 1000:
            self.__hangThanhVien = "Gold"
        elif self.__diemTichLuy >= 500:
            self.__hangThanhVien = "Silver"
        else:
            self.__hangThanhVien = "Standard"

    def Nhap(self):
        self.__maKhachHang = input("Ma khach hang: ")
        self.__hoTen = input("Ho ten khach: ")
        self.__soDienThoai = input("SDT: ")

    def Xuat(self):
        self.CapNhatHang()
        print(f"Khach hang: {self.__hoTen} ({self.__maKhachHang})")
        print("So dien thoai:", self.__soDienThoai)
        print("Diem tich luy:", self.__diemTichLuy)
        print("Hang thanh vien:", self.__hangThanhVien)


class Ve(IBanDuoc):
    demVe = 0 

    def __init__(self, maVe, suatChieu, ghe, khachHang):
        self.__maVe = maVe
        self.__suatChieu = suatChieu
        self.__ghe = ghe
        self.__khachHang = khachHang
        self.__daHuy = False
        self.__giaVe = 0
        self.TinhGiaVe()

    def getMaVe(self):
        return self.__maVe

    def getGiaVe(self):
        return self.__giaVe

    def getDaHuy(self):
        return self.__daHuy

    @staticmethod
    def SinhMaVe():
        Ve.demVe += 1
        return "V" + str(Ve.demVe).zfill(3)

    @staticmethod
    def DatVe(lichChieu, khachHang):
        if khachHang is None:
            print("Chua co thong tin khach hang.")
            return None

        suat = SuatChieu.ChonSuatChieu(lichChieu)
        if suat is None:
            print("Da huy thao tac dat ve.")
            return None

        ghe = Ghe.ChonGhe(suat.getPhongChieu())
        if ghe is None:
            print("Da huy thao tac dat ve.")
            return None

        if not ghe.DatGhe():
            print("Ghe vua bi dat mat. Vui long thu lai.")
            return None

        ve = Ve(Ve.SinhMaVe(), suat, ghe, khachHang)
        NhatKyHeThong.GhiLog(f"Dat ve {ve.getMaVe()} - ghe {ghe.getMaGhe()} - suat {suat.getMaSuat()}")
        print("--- Dat ve thanh cong ---")
        ve.Xuat()
        return ve

    def TinhGiaVe(self):
        giaPhim = self.__suatChieu.getGiaCoBan()
        giaGhe = self.__ghe.LayGiaGhe()
        giamGia = self.__khachHang.TinhGiamGia(giaPhim + giaGhe)
        self.__giaVe = giaPhim + giaGhe - giamGia

    def __add__(self, other):
        if isinstance(other, Ve):
            return self.__giaVe + other.getGiaVe()
        return self.__giaVe + other

    def __radd__(self, other):  
        return other + self.__giaVe

    def LayGia(self):
        return self.__giaVe

    def LayMoTa(self):
        return (f"Ve: {self.__maVe} - Suat chieu: {self.__suatChieu.getMaSuat()} - "
                f"Ghe: {self.__ghe.getMaGhe()} - Gia: {self.__giaVe} VND")

    def HuyVe(self):
        if self.__daHuy:
            return False
        self.__daHuy = True
        self.__ghe.HuyDat()
        return True

    def NoiDungIn(self):
        noiDung = f"Ma ve: {self.__maVe}\n"
        noiDung += f"Phim: {self.__suatChieu.getPhim().getTen()}\n"
        noiDung += f"Ghe: {self.__ghe.getMaGhe()}\n"
        noiDung += f"Khach hang: {self.__khachHang.getHoTen()}\n"
        noiDung += f"Gia ve: {self.__giaVe} VND"
        return noiDung

    def Xuat(self):
        print(self.NoiDungIn())

class HoaDon:
    def __init__(self, maHoaDon="", khachHang=None):
        self.__maHoaDon = maHoaDon
        self.__khachHang = khachHang
        self.__danhSach = []
        self.__tongTien = 0

    def getMaHoaDon(self):
        return self.__maHoaDon

    def getTongTien(self):
        return self.__tongTien

    def SoLuongMon(self):
        return len(self.__danhSach)

    def Them(self, mon):
        if not isinstance(mon, IBanDuoc):
            print("Mon khong hop le.")
            return
        self.__danhSach.append(mon)
        self.TinhTongTien()

    def TinhTongTien(self):
        self.__tongTien = 0
        for mon in self.__danhSach:
            self.__tongTien += mon.LayGia() 

    def NhapMaHoaDon(self):
        while True:
            ma = input("Nhap ma hoa don: ").strip()
            if ma != "":
                self.__maHoaDon = ma
                break
            print("Ma hoa don khong duoc de trong. Nhap lai.")

    def Nhap(self, lichChieu):
        self.NhapMaHoaDon()
        dangMua = True
        while dangMua:
            print("\n===== MENU MUA HANG =====")
            print("1. Dat ve xem phim")
            print("2. Mua combo bap nuoc")
            print("3. Xem hoa don tam tinh")
            print("0. Ket thuc va thanh toan")
            chon = input("Lua chon: ").strip()

            if chon == "1":
                ve = Ve.DatVe(lichChieu, self.__khachHang)
                if ve is not None:
                    self.Them(ve)
            elif chon == "2":
                combo = ComboBapNuoc.ChonCombo()
                if combo is not None:
                    self.Them(combo)
                    print("Da them:", combo.LayMoTa())
            elif chon == "3":
                self.Xuat()
            elif chon == "0":
                if len(self.__danhSach) == 0:
                    xacNhan = input("Hoa don dang trong. Ban co chac muon thoat? (c/k): ").strip().lower()
                    if xacNhan != "c":
                        continue
                dangMua = False
            else:
                print("Lua chon khong hop le. Vui long nhap lai.")

        NhatKyHeThong.GhiLog(f"Lap hoa don {self.__maHoaDon} - {len(self.__danhSach)} mon - {self.__tongTien} VND")

    def HoaDonIn(self):
        noiDung = "===== HOA DON =====\n"
        noiDung += f"Ma hoa don: {self.__maHoaDon}\n"
        noiDung += f"Khach hang: {self.__khachHang.getHoTen()}\n"
        noiDung += "------- DANH SACH -------\n"
        for mon in self.__danhSach:
            noiDung += mon.LayMoTa() + "\n"
        noiDung += f"Tong tien: {self.__tongTien} VND"
        return noiDung

    def Xuat(self):
        print(self.HoaDonIn())

class CumRap:
    def __init__(self, maCumRap, tenCumRap, diaChi):
        self.__maCumRap = maCumRap
        self.__tenCumRap = tenCumRap
        self.__diaChi = diaChi
        self.__danhSachPhong = []
        self.__lichChieu = []
        self.__doanhThu = 0

    def getDoanhThu(self):
        return self.__doanhThu

    def ThemPhongChieu(self, phong):
        if phong is not None:
            self.__danhSachPhong.append(phong)

    def ThemSuatChieu(self, suat):
        if suat is not None:
            self.__lichChieu.append(suat)

    def CapNhatDoanhThu(self, tien):
        if tien > 0:
            self.__doanhThu += tien

    def LayDanhSachPhong(self):
        return self.__danhSachPhong

    def LayLichChieu(self):
        return self.__lichChieu

    def Xuat(self):
        print(f"Cum rap: {self.__tenCumRap} ({self.__maCumRap})")
        print("Dia chi:", self.__diaChi)
        print("So phong chieu:", len(self.__danhSachPhong))
        print("So suat chieu:", len(self.__lichChieu))
        print(f"Doanh thu: {self.__doanhThu} VND")

class NhatKyHeThong:
    nhatKy = []

    @staticmethod
    def GhiLog(noiDung):
        NhatKyHeThong.nhatKy.append(noiDung)

    @staticmethod
    def HienThiNhatKy():
        print("===== NHAT KY HE THONG =====")
        if len(NhatKyHeThong.nhatKy) == 0:
            print("Khong co ban ghi nao.")
            return
        for log in NhatKyHeThong.nhatKy:
            print(log)

    @staticmethod
    def SoLuongLog():
        return len(NhatKyHeThong.nhatKy)

if __name__ == "__main__":
    rap = CumRap("CR01", "Rap Phim ABC", "123 Le Loi, Q1")

    p1 = PhongChieu("P01", "Phong 1", 5, 8)
    p2 = PhongChieu("P02", "Phong 2", 4, 6)
    rap.ThemPhongChieu(p1)
    rap.ThemPhongChieu(p2)

    rap.ThemSuatChieu(SuatChieu("SC01", DSPhim[0], p1, "18:00", DSPhim[0].LayGia()))
    rap.ThemSuatChieu(SuatChieu("SC02", DSPhim[1], p1, "21:00", DSPhim[1].LayGia()))
    rap.ThemSuatChieu(SuatChieu("SC03", DSPhim[2], p2, "19:00", DSPhim[2].LayGia()))
    rap.ThemSuatChieu(SuatChieu("SC04", DSPhim[3], p2, "12:00", DSPhim[3].LayGia()))
    rap.ThemSuatChieu(SuatChieu("SC05", DSPhim[4], p2, "16:00", DSPhim[4].LayGia()))

    Ghe.NhapGiaTuMay()

    print("===== THONG TIN KHACH HANG =====")
    khach = KhachHang()
    khach.Nhap()
    NhatKyHeThong.GhiLog("Nhap khach hang: " + khach.getHoTen())

    hoaDon = HoaDon("", khach)
    hoaDon.Nhap(rap.LayLichChieu())

    if hoaDon.SoLuongMon() > 0:
        print()
        hoaDon.Xuat()
        rap.CapNhatDoanhThu(hoaDon.getTongTien())
        khach.CongDiem(hoaDon.getTongTien())

    print()
    khach.Xuat()
    print()
    rap.Xuat()
    print()
    NhatKyHeThong.HienThiNhatKy()
